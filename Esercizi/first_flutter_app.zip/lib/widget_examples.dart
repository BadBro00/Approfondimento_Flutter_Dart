import 'dart:math';

import 'package:flutter/material.dart';

class WidgetsExample extends StatefulWidget {
  const WidgetsExample({super.key});

  @override
  State<WidgetsExample> createState() => _WidgetsExampleState();
}

class _WidgetsExampleState extends State<WidgetsExample> {
  //definizione di una proprietà di cui gestiremo lo stato 
  Color _textColor = Colors.black; 
  void changeTextColor() {
    setState(() {
      _textColor = Color((Random().nextDouble() * 0xFFFFFF).toInt()).withOpacity(1.0);
    });
  }

  @override
  Widget build(BuildContext context) {
    //scaffold, contenitore generico che prepara la pagina 
    return Scaffold(
      //appbar : barra superiore - per non ripeterla sempre possiamo crearne una noi
        appBar: AppBar(
        title: const Text('Flutter Widgets Example'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
  ),
  //definizione del corpo della pagina - ListView per creare una lista di elementi
  body: ListView(
    //ha la proprietà children per indicare i widget della lista
    children: <Widget>[
      //Crea un widget che combina le strutture di painting, dimensione e posizione dei widget
      Container(
        padding: EdgeInsets.all(15), //inserimento del padding globale
        //figlio del container - widget verticale
        child:  Column( 
          //poniamo al centro della colonna tutti gli elementi
          crossAxisAlignment: CrossAxisAlignment.center,
          //indichiamo i widget figli
          children: [
            const Text('Titolo Colonna',
            //stilizziamo il testo
            style: TextStyle(fontSize: 24, color: Colors.blueAccent),
            ),
            
            //inseriamo una riga sottostante
            Row( 
              //distribuzione degli elementi figli
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              
              children: <Widget> [ 
                 Padding(
                   padding: const EdgeInsets.all(8.0),
                   child: Container(
                        color: Colors.blue,
                        width: 50.0,
                        height: 50.0,
                      ),
                 ),
                    Container(
                      color: Colors.green,
                      width: 50.0,
                      height: 50.0,
                    ),
                    Container(
                      color: Colors.red,
                      width: 50.0,
                      height: 50.0,
                    ),
              ],
            ),
             Image.network(
                  'https://via.placeholder.com/150',
                  width: 150.0,
                  height: 150.0,
                ),
                //Blocco di spazio
                const SizedBox( 
                  height: 10,
                ),
                const Row( 
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget> [ 
                   Icon(
                    Icons.phone,
                    color: Colors.red,
                    size: 15,
                    ),
                  Icon(Icons.email),
                  Icon(Icons.flag),
                  ]
                )
          ],
        ),
      ),
      //definizione di un box contenitore in cui inserire una griglia
      SizedBox(
         width: 100.0,
         height: 400.0,
         child:  GridView.builder(
          //gridDelegate attributo obbligatorio che riceve una classe per definire una
          //griglia con un numero fisso di colonne
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, //specifica il numero massimo di colonne,
                mainAxisSpacing: 2.2, //specifica la distanza tra le righe
                crossAxisSpacing: 1, // specifica la distanza tra le colonne
                childAspectRatio: 0.4 //rapporto tra l'estensione dell'asse trasversale e quella dell'asse principale di ciascun elemento figlio.
              ),
               itemCount: 5,
              itemBuilder: (context, index){
                 return Container(
                  alignment: Alignment.center,
                  color: Colors.blue[100 * (index % 6)],
                  child: Text('$index'),
                );
              }
      )
      ),
      Padding(
        padding: const EdgeInsets.all(10.0),
        child: Container( 
          child: Column( 
            children: [
              Text('Testo con colore random',
               style: TextStyle(
                    fontSize: 20.0,
                    color: _textColor,
                  ),
              ),
               const SizedBox(height: 20.0),
                                 Tooltip(
                    message: _textColor.value.toRadixString(16),
                    child: GestureDetector(
               child : ElevatedButton(
                  onPressed: changeTextColor,
                  child: Text('cambia colore'),
                ),
                  ),
                  )
              ],
          ),
        ),
      )
    ],
  ),

    );
  }
}
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_firebase_app/authenticate_remote.dart';
import 'package:cloud_functions/cloud_functions.dart';

Future<List<String>> getEmails() async {
  final HttpsCallable callable = FirebaseFunctions.instance.httpsCallable('getUserEmails');
  final HttpsCallableResult result = await callable.call();
  final List<dynamic> emails = result.data;
  return emails.cast<String>();
}

class UserWidget extends StatefulWidget{
  const UserWidget({super.key});
  @override
  State<UserWidget> createState()=>_UserWidgetState();
}

class _UserWidgetState extends State<UserWidget>{
  //var fbAuth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Utenti dell\'app',style: TextStyle(color: Colors.black),),
        backgroundColor: Colors.tealAccent,
      ),
      body:FutureBuilder<List<String>>(
        future: getEmails(),
        builder: (BuildContext context, AsyncSnapshot<List<String>> snapshot){
          if(snapshot.connectionState==ConnectionState.waiting){
            return const Center(child: CircularProgressIndicator(color: Colors.white,),);
          }else if(snapshot.hasError){
            return Text("Errore fetch: ${snapshot.error}");
          }else{
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (
                BuildContext context, int index
              ){
                return ListTile(
                  title: Text(snapshot.data![index]),
                );
              },
            );
          }
        }
      )
    );
  }
}
//import 'dart:convert';

import 'package:flutter/material.dart';

class HomeWidget extends StatefulWidget{
  const HomeWidget({super.key});
  
  @override
  State<HomeWidget> createState()=>_HomeWidgetState();
}

class _HomeWidgetState extends State<HomeWidget>  with SingleTickerProviderStateMixin {
  bool isFavorite=false;

  late AnimationController _animationController;
  late PageController _controller;
  
  @override
  void initState(){
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 250),
      vsync: this,
    );
    _controller=PageController();
  }

  @override
  void dispose(){
    _animationController.dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Amazozz"),
        backgroundColor: Colors.cyanAccent,
      ),
    body: LayoutBuilder(
      builder: (context, constraints) {
      return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.amber,
        body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 150,
                width: double.infinity,
                child: 
                Image.network(
                  'https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697',
                  fit: BoxFit.cover,
                )
              ),
                const SizedBox(height: 15),
                Expanded(
                  child: Stack(
                      children: [
                          Stack(children: [
                            PageView(
                              controller: _controller,
                                children: [
                                  _buildPage('Slide 1','https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697'),
                                  _buildPage('Slide 2','https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697'),
                                  _buildPage('Slide 3','https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697'),
                                ],
                              ),    
                            ]
                          ),
                          ElevatedButton(
                            onPressed: (){
                              Navigator.pushNamed(context, '/product');
                            },
                            child: const Text('Vai al prodotto')
                          ),
                          Positioned(
                            left: 200,
                            child:ElevatedButton(
                              onPressed: (){
                                Navigator.pushNamed(context,'/third');
                              },
                              child: const Text('Home')
                            ),
                          ),
                          Positioned(
                            left: 350,
                            child:ElevatedButton(
                              onPressed: (){
                                  Navigator.pushNamed(context, '/table');
                              },
                              child: const Text('Vetrina'),
                            ),
                          ),
                          GestureDetector(
                            onHorizontalDragUpdate: (details){
                              final dx = details.delta.dx;
                              if(dx.abs()>1){
                                _controller.position.moveTo(_controller.position.pixels-dx);
                              }
                            },
                          ),
                        ]
                      ),
                    )
                  ],
                ),
              ),
          );
        },
      ),
    );
  }
}

Widget _buildPage(String pagename, String img){
  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 12),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.tealAccent,
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 100,
          width: double.infinity,
          child: Image.network(
            img,
            fit: BoxFit.contain,
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                pagename,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              )
            ],
          ),
        )
      ],
    ),
  );
}
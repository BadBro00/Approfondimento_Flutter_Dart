import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'authenticate_remote.dart';

class RegisterWidget extends StatefulWidget{
  const RegisterWidget({super.key});
  @override
  State<RegisterWidget> createState()=>_RegisterWidgetState();
}

class _RegisterWidgetState extends State<RegisterWidget>{
  bool isFavorite = false;
  final GlobalKey<FormState> _regKey = GlobalKey();
  bool _isPwVisible = false;
  AuthenticationRemote auth = AuthenticationRemote();
  String _errMsg = '';
  String _email = '';
  String _password = '';
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Registrazione'),
        backgroundColor: Colors.tealAccent,
      ),
      body: Form(
        key: _regKey,
        child:
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Flexible(
              child: TextFormField(
                decoration: const InputDecoration(
                  icon: Icon(Icons.mail),
                  labelText: 'Email',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Inserisci un email valida';
                  }
                  return null;
                },
                onSaved: (value) {
                  _email = value!;
                },
              ),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Flexible(
                  child: TextFormField(
                    decoration: InputDecoration(
                      icon: const Icon(Icons.lock),
                      labelText: 'Password',
                      suffixIcon: IconButton(
                        icon: Icon(_isPwVisible? Icons.visibility: Icons.visibility_off,),
                        onPressed: () {
                          _isPwVisible = !_isPwVisible;
                        },
                      ),
                    ),
                    obscureText: !_isPwVisible,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Inserire la propria password';
                      }
                      return null;
                    },
                    onSaved: (value) {
                      _password = value!;
                    },
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: ElevatedButton(
                onPressed: () async {
                  if (_regKey.currentState?.validate() ?? false) {
                    _regKey.currentState?.save();
                    try{
                      await auth.register(_email, _password);
                    } on FirebaseAuthException catch(e){
                      if(e.code=='email-already-in-use'){
                        setState(
                          (){
                            _errMsg = 'L\'indirizzo mail è già in uso!';
                          }
                        );
                      }
                    }
                    if(_regKey.currentState!=false){
                      Navigator.pushNamed(context,'/login');
                    }
                  }
                },
                child: const Text('Register'),
              ),
            ),
            Text(
              _errMsg,
              style: const TextStyle(color: Colors.red),
            )
          ],
        ),
      )
    );
  }
}
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_firebase_app/authenticate_remote.dart';

class LoginWidget extends StatefulWidget{
  const LoginWidget({super.key});
  @override
  State<LoginWidget> createState()=>_LoginWidgetState();
}

class _LoginWidgetState extends State<LoginWidget>{
  var fbAuth = FirebaseAuth.instance;
  bool isFavorite = false;
  final GlobalKey<FormState> _logKey = GlobalKey();
  bool _isLogPwVisible = false;
  AuthenticationRemote auth = AuthenticationRemote();
  String _email = '';
  String _password = '';
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Login Page',style: TextStyle(color: Colors.black),),
        backgroundColor: Colors.tealAccent,
      ),
      body: Form(
        key: _logKey,
        child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Flexible(
            child: TextFormField(
              decoration: const InputDecoration(
                icon: Icon(Icons.mail),
                labelText: 'Email',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Inserisci un email valida';
                }
                return null;
              },
              onSaved: (value) {
                _email = value!;
              },
            ),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Flexible(
                child: TextFormField(
                  decoration: InputDecoration(
                    icon: const Icon(Icons.lock),
                    labelText: 'Password',
                    suffixIcon: IconButton(
                      icon: Icon(_isLogPwVisible? Icons.visibility: Icons.visibility_off,),
                      onPressed: () {
                        _isLogPwVisible = !_isLogPwVisible;
                      },
                    ),
                  ),
                  obscureText: !_isLogPwVisible,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Inserire la propria password';
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _password = value!;
                  },                  
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: ElevatedButton(
              onPressed: () async {
                if(_logKey.currentState!.validate()){
                  _logKey.currentState!.save();
                  try{
                    UserCredential usrCred = await FirebaseAuth.instance.signInWithEmailAndPassword(email: _email, password: _password);
                    print('Utente loggato: ${usrCred.user!.email}');
                    Navigator.pushNamed(context, '/third');
                  }on FirebaseAuthException catch(e){
                    if(e.code=='user-not-found'){
                      print('Nessun utente trovato');
                    }else if(e.code=='wrong-password'){
                      print('Password errata!');
                    }
                  }
                }
              },
              child: const Text('Login'),
            ),
          ),
        ],
      ),
      )
    );
  }
}
import 'package:firebase_auth/firebase_auth.dart';

abstract class AuthenticationSource{
  Future<void> register(String email, String pw);
} 

class AuthenticationRemote extends AuthenticationSource{
  
  final FirebaseAuth _auth = FirebaseAuth.instance;

  get currentUser => null;
  
  @override
  Future<void> register(String email,String pw) async{
    await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: pw);
  }

  Future<UserCredential> login(String email, String pw) async{
    return await _auth.signInWithEmailAndPassword(email: email,password: pw);
  }
}
import 'package:flutter/material.dart';

class ItemsWidget extends StatefulWidget{
  const ItemsWidget({super.key});
  @override
  State<ItemsWidget> createState()=>_ItemsWidgetState();
}

class _ItemsWidgetState extends State<ItemsWidget> with SingleTickerProviderStateMixin{
  bool isFavorite = false;
  @override
  Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: Colors.tealAccent,
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Oggetti in vetrina'),
        backgroundColor: Colors.tealAccent,
      ),
      body: MaterialApp(
            home: Scaffold(
              body: Padding(
                padding: const EdgeInsets.all(7),
                child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                    const Text(
                      'Amazozz',
                      style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.bold
                      ),
                      selectionColor: Colors.amber,
                    ),
                    Table(
                      children: [
                        TableRow(
                          children: [
                            Stack(
                              children: [
                                Image.network('https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697',fit: BoxFit.scaleDown,),
                                IconButton(
                                  icon: isFavorite ? const Icon(Icons.favorite_border) : const Icon(Icons.favorite),
                                  onPressed: () {
                                    isFavorite = !isFavorite;
                                  },
                                ),
                              ],
                            ),
                            Stack(
                              children: [
                                Image.network('https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697',fit: BoxFit.scaleDown,),
                                IconButton(icon: isFavorite ? const Icon(Icons.favorite_border) : const Icon(Icons.favorite),
                                  onPressed: () {
                                    isFavorite = !isFavorite;
                                  },
                                ),
                              ],
                            ),
                          ],  
                        )
                      ],
                    ),
                    Row(
                      children: [
                        ElevatedButton(
                          child: const Text('Swipe Page'),
                          onPressed: (){
                            Navigator.pushNamed(context, '/third');
                          },
                        ),
                        ElevatedButton(
                          onPressed: (){
                            Navigator.pushNamed(context,'/third');
                          },
                          child: const Text('Home')
                        ),
                        Positioned(
                          left: 0,
                          child: ElevatedButton(
                            onPressed: (){
                              if(Navigator.canPop(context)){
                                Navigator.pop(context);
                              }else{
                                Navigator.pushNamed(context, '/third');
                              }
                            },
                          child: const Text('Back'),
                          ),
                        ),
                      ]
                    ),
                  ]
                ),
              ),
            )
          )
        );
  }
}
import 'dart:async';
import 'dart:html';
Future<int> waiter (int s) async {
    int i=0;
    while(i<s){
      await Future.delayed(Duration(seconds: 1));
      querySelector('.secondi')?.text="Tempo passato: $i secondi";
      i++;
    }
    querySelector('.secondi')?.text="Timer di $s secondi terminato.";
    return i;
}
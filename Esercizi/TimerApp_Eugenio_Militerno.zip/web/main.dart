//import 'package:web/helpers.dart';
import 'dart:html';
import 'custom_timer.dart';
void main() {
  
  DivElement div = DivElement();
  LabelElement lab = LabelElement()
  ..text = "Inserisci secondi";
  InputElement input = InputElement();
  ButtonElement button = ButtonElement()
  ..text="Aspettiamo!";
  div.children.add(lab);
  div.children.add(input);
  div.children.add(button);
  document.body?.children.add(div);
  DivElement div2 = DivElement()
  ..text=" ";
  document.body?.children.add(div2);
  button.onClick.listen((event){
    if(input.value != null){
      int? sec = int.tryParse(input.value!);
      if(sec!=null){
        waiter(sec);
      }
      else{
        window.alert('Inserisci un valore valido!');
        input.text="0";
      }
   }
  });
}
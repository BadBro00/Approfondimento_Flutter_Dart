import 'package:flutter/material.dart';

class LondonWidget extends StatefulWidget{
  const LondonWidget({super.key});
  
  @override
  State<LondonWidget> createState()=>_LondonWidgetState();
}

class _LondonWidgetState extends State<LondonWidget>  with SingleTickerProviderStateMixin {
  bool isFavorite=false;

  late AnimationController _animationController;
  late PageController _controller;
  
  @override
  void initState(){
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 250),
      vsync: this,
    );
    _controller=PageController();
  }

  @override
  void dispose(){
    _animationController.dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("London Trip"),
        backgroundColor: Colors.cyanAccent,
      ),
    body: LayoutBuilder(
      builder: (context, constraints) {
      return MaterialApp(
      home: Scaffold(
        body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 150,
                width: double.infinity,
                child: 
                Image.asset(
                  'assets/London.jpg',
                  fit: BoxFit.cover,
                )
              ),
              Padding(
                padding: const EdgeInsets.all(7),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('London Trip',style: TextStyle(fontSize: 40,fontWeight: FontWeight.bold),),
                        SizedBox(height: 5),
                        Text(
                          'Tour a per',
                          style: TextStyle(
                            fontSize: 20,fontWeight: FontWeight.w300,
                            color: Colors.red,
                          ),
                        )
                      ],
                    ),
                    IconButton(
                      icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border),
                      onPressed: (){
                        setState(() {
                          isFavorite=!isFavorite;
                        });
                      },
                    )
                  ],
                ),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    'Visite guidate',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.normal
                    ),
                  ),
                ),
                const SizedBox(height: 15),
                Expanded(
                  child: GestureDetector(
                    onHorizontalDragUpdate: (details){
                      final dx = details.delta.dx;
                      if(dx.abs()>1){
                        _controller.position.moveTo(_controller.position.pixels-dx);
                      }
                    },
                    child: PageView(
                      controller: _controller,
                      children: [
                        _buildPage('Eye','assets/Eye.jpg'),
                        _buildPage('Gallery','assets/Gallery.jpg'),
                        _buildPage('Palace','assets/Palace.jpg'),
                      ],
                    ),
                  ),
                )
              ],
          ),
        ),
      );
    },
  ),
  );
  }
}

Widget _buildPage(String pagename, String img){
  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 14,vertical: 12),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Colors.grey,
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 100,
          width: double.infinity,
          child: Image.asset(
            img,
            fit: BoxFit.contain,
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                pagename,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              )
            ],
          ),
        )
      ],
    ),
  );
}
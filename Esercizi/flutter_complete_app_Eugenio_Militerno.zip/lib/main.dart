import 'package:flutter/material.dart';
import 'package:flutter_complete_app/items_display.dart';
import 'package:flutter_complete_app/widgets_list.dart';


void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      color: Colors.tealAccent,
      title: "Complete App",
      theme: ThemeData(
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Colors.black),
        ),
        useMaterial3: true,
      ),
      home: HomePage(),
      routes: {
        '/home':(context)=> HomePage(),
        '/second': (context)=> const ItemsWidget(),
        '/third' : (context)=> const HomeWidget(),
        '/product': (context)=> ProductPage(), 
      },
    );
  }
}

class HomePage extends StatelessWidget{
  HomePage({super.key});
  bool isFavorite = false;
  @override
  Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: Colors.tealAccent,
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Amazozz"),
        backgroundColor: Colors.amber,
      ),
      body: Center(
        child: Column(
          children: [
            SizedBox(
              height: 150,
              child: Image.network('https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697',fit: BoxFit.cover,)
            ),
            const Divider(color: Colors.amber,),
            Table(
              children: [
                TableRow(
                  children: [
                    Stack(
                      children: [
                        Image.network('https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697',fit: BoxFit.scaleDown,),
                        IconButton(
                          icon: isFavorite ? const Icon(Icons.favorite_border) : const Icon(Icons.favorite),
                          onPressed: () {
                            isFavorite = !isFavorite;
                          },
                        ),

                      ],
                    ),
                    Stack(
                      children: [
                        Image.network('https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697',fit: BoxFit.scaleDown,),
                        IconButton(
                          icon: isFavorite ? const Icon(Icons.favorite_border) : const Icon(Icons.favorite),
                          onPressed: () {
                            isFavorite = !isFavorite;
                          },
                        ),
                      ],
                    ),
                  ],  
                )
              ],
            ),
            ElevatedButton(
              child: const Text('Oggetti in vetrina'),
              onPressed: (){
                Navigator.pop(context);
                Navigator.pushNamed(context, '/second');
              },
            ),
          ]
        ),
      ),
    );
  }
}

class ProductPage extends StatelessWidget{
  ProductPage({super.key});

  final List<int> idxs = [0,1,2];

  @override
  Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: Colors.tealAccent,
      appBar: AppBar(
        title: const Text('Amazozz'),
        backgroundColor: Colors.amber,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          children: [
            SizedBox(
              height: 150,
              width: double.infinity,
              child: Image.network('https://thedomesticatedman.files.wordpress.com/2013/10/amazon-banner.png?w=697'),
            ),
            ElevatedButton(
              onPressed: (){
                Navigator.pop(context);
                Navigator.pushNamed(context,'/home');
              },
              child: const Text('Home')
            ),
            ElevatedButton(
              onPressed: (){
                if(Navigator.canPop(context)){
                  Navigator.pop(context);
                }else{
                  Navigator.pushNamed(context, '/home');
                }
              },
              child: const Text('Back'),
            ),
          ],
        ),
      ),
    );
  }
}
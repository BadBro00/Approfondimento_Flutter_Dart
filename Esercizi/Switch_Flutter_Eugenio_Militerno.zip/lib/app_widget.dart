import 'package:flutter/material.dart';
//import 'package:switch_flutter_app/main.dart';

class AppWidget extends StatefulWidget{
  const AppWidget({super.key});
  @override
  State<AppWidget> createState()=>_AppWidgetState();
}

class _AppWidgetState extends State<AppWidget>{
  //Color _txtColor = Colors.black;
  bool _switchValue=false;
  String _username="";
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.network('https://cdn0.iconfinder.com/data/icons/apple-apps/100/Apple_Settings-512.png'),
            TextField(onChanged: (value){setState(() {_username = value;});},decoration: const InputDecoration(labelText: "username")),
            const SizedBox(height: 20),
            Switch(value: _switchValue,onChanged: (value){setState(() {_switchValue=value;});
            showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: const Text('Switch Pressed'),
                        content: const Text('Lo switch è stato premuto'),
                        actions: [
                          TextButton(
                            child: const Text('OK'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                      ),
                    ],
                  );
                },
              );
            })
          ], 
        ),
      ),
    );
  }
}


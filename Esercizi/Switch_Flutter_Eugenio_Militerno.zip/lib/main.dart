import 'package:flutter/material.dart';
import 'package:switch_flutter_app/app_widget.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "switch app",
      theme:  ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.cyan.shade400),
        useMaterial3: true,
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontSize: 24,fontWeight: FontWeight.bold,fontFamily: 'Courier New'),
        ),
      ),
      home : const AppWidget()
    );
  }
}

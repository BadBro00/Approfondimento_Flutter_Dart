import 'package:flutter/material.dart';
import 'package:table_app_flutter/table_widget.dart';
void main() {
  runApp(const TableApp());
}

class TableApp extends StatelessWidget {
  const TableApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "TableApp",
      theme: ThemeData(
        useMaterial3: true,
      ),
      home: const TableWidget(),
    );
  }
}


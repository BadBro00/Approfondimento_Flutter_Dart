import 'package:flutter/material.dart';

class TableWidget extends StatefulWidget{
  const TableWidget({super.key});
  @override
  State<TableWidget> createState()=>_TableWidgetState();
}

class _TableWidgetState extends State<TableWidget> {
  String? selectedImage;
  List<String> imageURLS = [
    'https://siviaggia.it/wp-content/uploads/sites/2/2020/08/Vesuvio.jpg',
    'https://fai-platform.imgix.net/media/campania/na/21600_golfo-di-napoli.jpg?crop=fit&w=1440&h=800&auto=format,compress',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1aXd73JLgE5XvKmV4gyOsCtbzEtZpLmpozIKqTR8_eQ&s',
    'https://dimages2.corriereobjects.it/files/gallery_main_crop_mobile/uploads/2024/02/16/65cf658d1b922.jpeg',
    'https://media.tacdn.com/media/attractions-splice-spp-674x446/0b/39/a7/1c.jpg',
    'https://images.prismic.io/eataly-us/ed3fcec7-7994-426d-a5e4-a24be5a95afd_pizza-recipe-main.jpg?auto=compress,format'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Foto della Settimana"),
        backgroundColor: Colors.cyanAccent,
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return Column(
            children: [
              Container(
                height: constraints.maxHeight * 0.6, // Imposta l'altezza a 60% dell'altezza disponibile
                child: SingleChildScrollView(
                  child: AspectRatio(
                    aspectRatio: 0.7,
                    child: Table(
                      children: List.generate(2, (row) => TableRow(
                        children: List.generate(3, (col) {
                          int idx = row * 3 + col;
                          String imageUrl = imageURLS[idx];
                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedImage = imageUrl;
                              });
                            },
                            child: Container(
                              margin: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.black),
                              ),
                              child: AspectRatio(
                                aspectRatio: 1,
                                child: Image.network(imageUrl,fit: BoxFit.cover),
                              ),
                            ),
                          );
                        }),
                      )),
                    ),
                  ),
                ),
              ),
              if (selectedImage != null)
                Flexible(
                  fit: FlexFit.tight,
                  child: Image.network(selectedImage!),
                ),
            ],
          );
        },
      ),
    );
  }
}
import 'package:flutter/material.dart';
void main() {
  runApp(MainApp());
}

class MyApp extends StatelessWidget{
  const MyApp({super.key});
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      title: 'My App',
      home: Scaffold(
        body: MainApp(),
      ),
    );
  }
}
// ignore: must_be_immutable
class MainApp extends StatelessWidget {
  MainApp({super.key});
  bool isVisible = false;
  final _formKey = GlobalKey<FormState>();
  final _usernameControl = TextEditingController();
  final _passwordControl = TextEditingController();
  final _confirmPasswordControl = TextEditingController();
  String username = '';
  String password = '';
  String confirmPassword = '';
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ScaffoldMessenger(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Material(
              color: Colors.lightBlue,
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                        TextFormField(
                          autofocus: true,
                          decoration: const InputDecoration(
                            label: Text('Username'),
                          ),
                          controller: _usernameControl,
                          textDirection: TextDirection.ltr,
                          obscureText: false,
                          validator: (value){
                          if(value==null||value.isEmpty){
                            return 'Campo Obbligatorio!';
                          }
                          return null;
                          },
                        ),
                        const Divider(color: Colors.amber,),
                        Row(
                          children: [
                            TextFormField(
                              autofocus: true,
                              decoration: const InputDecoration(
                                label: Text('Password'),
                              ),
                              controller: _passwordControl,
                              obscureText: false,
                              validator: (value){
                                password=value!;
                                // ignore: unnecessary_null_comparison
                                if(value==null||value.isEmpty){
                                  return 'Campo Obbligatorio!';
                                }else if(value.length < 8 && !value.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]')  )){
                                  return 'Password debole';
                                }
                                return null;
                              },
                            ),
                            IconButton(icon: Icon(isVisible ? Icons.enhanced_encryption_outlined : Icons.enhanced_encryption_rounded), onPressed: (){
                              isVisible = !isVisible;
                                if(isVisible){
                                  _passwordControl.text.replaceRange(0, _passwordControl.text.length, '*');
                                }
                              },                           
                            ),
                          ]
                        ),
                        Row(
                          children: [
                            TextFormField(
                              autofocus: true,
                              decoration: const InputDecoration(
                                label: Text('Password'),
                              ),
                              controller: _confirmPasswordControl,
                              obscureText: false,
                              validator: (value){
                                password=value!;
                                // ignore: unnecessary_null_comparison
                                if(value==null||value.isEmpty){
                                  return 'Campo Obbligatorio!';
                                }else if(value.length < 8 && !value.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]')  )){
                                  return 'Password debole';
                                }
                                return null;
                              },
                            ),
                            IconButton(icon: Icon(isVisible ? Icons.enhanced_encryption_outlined : Icons.enhanced_encryption_rounded), onPressed: (){
                              isVisible = !isVisible;
                                if(isVisible){
                                  _confirmPasswordControl.text.replaceRange(0, _confirmPasswordControl.text.length, '*');
                                }
                              },                           
                            ),
                          ]
                        ),
                      Scaffold(
                        appBar: AppBar(
                          title: const Text('Scaffold'),
                        ),
                        body: Builder(builder: (BuildContext context){
                          return ElevatedButton(
                            onPressed: (){
                              if(_formKey.currentState!=null && _formKey.currentState!.validate()){
                                if(_passwordControl.text!=_confirmPasswordControl.text){
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      backgroundColor: Colors.red,
                                      content: Text('Le password non corrispondono!'),
                                    )
                                  );
                                }else{
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      backgroundColor: Colors.lightGreen,
                                      content: Text('Form inviato con successo'),
                                    ),
                                  );
                                }
                              }
                            },
                            child: const Text('Invia')
                          );
                        }),
                      )
                    ]
                  )
                )
              )
            )
          ),
        ) 
      )
    );
  }
}


//import 'package:web/helpers.dart';
import 'dart:html'; 

void main() {
  //final now = DateTime.now();
  //final element = document.querySelector('#output') as HTMLDivElement;
  //element.text = 'DateTime = ${now.hour}:${now.minute}:${now.second}';
  //
  HeadingElement heading = HeadingElement.h1();
  heading.text = 'heading';
  ParagraphElement paragraph = ParagraphElement();
  paragraph.text = 'paragraph';
  ButtonElement button = ButtonElement();
  button.text = 'click me';
  button.onClick.listen((event){window.alert('Button clicked');});
  ImageElement img = ImageElement();
  img.src='image.jpeg';
  InputElement textInput = InputElement(type: 'text');
  InputElement checkbox = InputElement(type: 'checkbox');
  SelectElement select = SelectElement();
  select.children.addAll([
    OptionElement(data: 'option1'),
    OptionElement(data: 'option2'),
    OptionElement(data: 'option3')
  ]);
  UListElement list = UListElement();
  list.children.addAll([
    LIElement()..text='Item 1',
    LIElement()..text='Item 2',
    LIElement()..text='Item 3'
  ]);
  TableElement table = TableElement();
  TableRowElement row = table.addRow();
  row.addCell().text='Header1';
  row.addCell().text='Header2';
  TableRowElement row2 = table.addRow();
  row2.addCell().text='Dato1';
  row2.addCell().text='Dato2';
  table.style
  ..border='1px solid break'
  ..borderCollapse='collapse';
  FormElement form = FormElement();
  LabelElement l1 = LabelElement()..text='label 1';
  LabelElement l2 = LabelElement()..text='label 2';
  InputElement inElement = InputElement()..text='...';
  form.children.addAll([
    l1,l2,inElement
  ]);
  TextAreaElement textElem = TextAreaElement();
  textElem.text='Inserisci commento';
  DivElement div = DivElement();
  div.text='div';
  div.id='myDiv';
  AnchorElement anchor = AnchorElement(href: 'https://www.google.com');
  anchor.text='google';
  div.children.add(anchor);
  div.style
  ..padding='20px'
  ..backgroundColor='aqua'
  ..textAlign = 'center';
  DivElement container = DivElement();
  container.id = 'flexContainer';
  container.style
  ..display='flex'
  ..flexDirection='row'
  ..flexWrap='wrap'
  ..justifyContent='space-around'
  ..alignItems='center'
  ..padding='20px'
  ..backgroundColor='lightgray';
  DivElement item1 = DivElement()..text='item1';
  DivElement item2 = DivElement()..text='item2';
  DivElement item3 = DivElement()..text='item3';
  DivElement item4 = DivElement()..text='item4';
  DivElement item5 = DivElement()..text='item5';
  item1.style.backgroundColor='lightblue';
  item2.style.backgroundColor='lightgreen';
  item3.style.backgroundColor='lightcoral';
  item4.style.backgroundColor='white';
  item5.style.backgroundColor='pink';
  //Classe oggetti - Condivisione proprietà
    //non so perchè dia errore, alla prof non lo dà
  document.head?.append(StyleElement()
    ..text = '.flexItem {padding: 5%; font-size: 18px;}');
    item1.classes.add('flexItem');
    item2.classes.add('flexItem');
    item3.classes.add('flexItem');
    item4.classes.add('flexItem');
    item5.classes.add('flexItem');
  container.children.addAll([item1,item2,item3,item4,item5]);
  DivElement heroSection = DivElement()
    ..id = 'hero'
    ..style.backgroundImage = 'url("https://st.depositphotos.com/2726735/3242/i/450/depositphotos_32422439-stock-photo-abstract-modern-city-background.jpg")'
    ..style.backgroundSize = 'cover'
    ..style.color = 'white'
    ..style.textAlign = 'center'
    ..style.padding = '100px 0';

  HeadingElement heroTitle = HeadingElement.h1()..text = 'Welcome to My Website';
  ButtonElement heroButton = ButtonElement()
    ..text = 'Learn More'
    ..style.padding = '10px 20px'
    ..style.backgroundColor = 'blue'
    ..style.color = 'white';

  heroSection.children.addAll([heroTitle, heroButton]);
  DivElement contentSection = DivElement()
    ..style.display = 'flex'
    ..style.justifyContent = 'center'
    ..style.padding = '50px 0';

  DivElement column1 = DivElement()
    ..style.flex = '1'
    ..style.padding = '0 20px';

  ParagraphElement descrizione = ParagraphElement()
    ..text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.';

  column1.children.add(descrizione);

  DivElement column2 = DivElement()
    ..style.flex = '1'
    ..style.padding = '0 20px';

  ImageElement imag = ImageElement(src: 'https://st.depositphotos.com/2726735/3242/i/450/depositphotos_32422439-stock-photo-abstract-modern-city-background.jpg')
    ..style.width = '100%';

  column2.children.add(imag);

    contentSection.children.addAll([column1, column2]);
  DivElement formSection = DivElement()
    ..style.textAlign = 'center'
    ..style.padding = '50px 0';

  FormElement contactform = FormElement()
  ..style.backgroundColor='lightblue'
  ..style.padding = '2%';
  DivElement emailDiv = DivElement()..style.marginBottom = '10px';
  LabelElement emailLabel = LabelElement()..text = 'Email:';
  InputElement emailInput = InputElement()
    ..type = 'email'
    ..placeholder = 'Enter your email';
  emailDiv.children.addAll([emailLabel, emailInput]);
  DivElement messageDiv = DivElement()..style.marginBottom = '10px';
  LabelElement messageLabel = LabelElement()..text = 'Message:';
  TextAreaElement messageTextarea = TextAreaElement()
    ..placeholder = 'Enter your message'
    ..style.marginTop = '10px';
  messageDiv.children.addAll([messageLabel, messageTextarea]);

  ButtonElement submitButton = ButtonElement()
    ..text = 'Submit'
    ..style.marginTop = '10px';

  contactform.onSubmit.listen((event) {
    event.preventDefault();
    if (emailInput.value!.isEmpty || messageTextarea.value!.isEmpty) {
      window.alert('Email and Message cannot be empty');
    } else {
      window.alert('Email: ${emailInput.value}\nMessage: ${messageTextarea.value}');
    }
  });
  formSection.children.add(contactform);
   contactform.children.addAll([emailDiv, messageDiv, submitButton]); 
  document.body?.children.addAll([heading, paragraph, button, imag, textInput, checkbox, select,list, table, form, textElem, div, container, ]);
  document.body?.children.addAll([heroSection, contentSection, formSection]);
}